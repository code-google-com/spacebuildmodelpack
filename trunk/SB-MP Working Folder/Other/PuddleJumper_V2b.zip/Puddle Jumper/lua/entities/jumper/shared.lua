ENT.Type = "vehicle"
ENT.Base = "base_anim"
ENT.PrintName	= "Puddle Jumper"
ENT.Author	= "Catdaemon -edit LightDemon/VoteKick"
ENT.Category 		= "Stargate";
ENT.Spawnable	= true
ENT.AdminSpawnable = false