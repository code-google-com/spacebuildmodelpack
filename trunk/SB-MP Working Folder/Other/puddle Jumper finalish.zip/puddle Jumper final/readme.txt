put jumper.lua in stargate/lua/weapons/gmod_tool/stools

I changed the controls
W = slow
Shift = fast
D = reverse
R = cloak
Left Click = fire
Right Click = track