ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Puddle Jumper"
ENT.Author = "Trigger/Catdaemon"
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""
ENT.Spawnable = true
ENT.AdminSpawnable = true

if ( CLIENT ) then

	ENT.LastA = 255

	function ENT:Draw( )
	
		self.Entity:DrawModel( )
		
		local r, g, b, a = self.Entity:GetColor( )
		local newa = a
		
		if ( a ~= self.LastA and a ~= 255) then return end
		
		if ( self.Entity:GetNWInt( 0 ) == LocalPlayer( ):EntIndex( ) ) then
		
			newa = math.max( a - 2, 80 )
		
		else
		
			newa = math.min( a + 2, 255 )
		
		end
		
		self.Entity:SetColor( r, g, b, newa )
		self.LastA = newa
		
	end

elseif ( SERVER ) then

	local LoopingSound = Sound( "Canals.d1_canals_01_chargeloop" )
	
	function ENT:SpawnFunction( Player, Trace )
	
		local SpawnAt = Trace.HitPos + Trace.HitNormal * 200
		local SpawnAngle = Player:GetRight( ):Angle( )
		
		local ent = ents.Create( "shuttle" )
			ent:SetPos( SpawnAt )
			ent:SetAngles( SpawnAngle )
			ent:Spawn( )
			ent:Activate( )
		return ent
	
	end
	
	function ENT:Initialize( )
	
		self.Sound = self.Sound or CreateSound( self.Entity, LoopingSound )
		
		self.Entity:SetUseType( SIMPLE_USE )
		
		self.Accel = 0
		self.FireTrail = nil
		self.InFlight = false
		self.Pilot = nil
		self.Entity:SetModel( "models/props_combine/headcrabcannister01a.mdl" )
		self.Entity:PhysicsInit( SOLID_VPHYSICS )
		self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
		self.Entity:SetSolid( SOLID_VPHYSICS )
		
		local PhysObj = self.Entity:GetPhysicsObject( )
			if ( PhysObj:IsValid( ) ) then
			
				PhysObj:Wake( )
				PhysObj:SetMass( 10000 )
				
			end
			
		self.Entity:StartMotionController( )
	
	end
	
	function ENT:OnRemove( )
	
		if ( self.Sound ) then self.Sound:Stop( ) end
	
	end
	
	function ENT:Think( )
	
		if ( self.InFlight ) then
		
			if ( self.Pilot:KeyDown( IN_USE ) or self.Pilot:Health( ) <= 0 ) then
		                self.Entity:SetModel( "models/props_combine/headcrabcannister01a.mdl" )
				self.Sound:Stop( )
				
				if ( self.Pilot:Health( ) > 0 ) then
				
					self.Pilot:UnSpectate( )				
					self.Pilot:DrawViewModel( true )
					self.Pilot:DrawWorldModel( true )
					self.Pilot:Spawn( )
				
				end
				
				self.Pilot:SetPos( self.Entity:GetPos( ) + Vector( 0, 0, 50 ) + ( self.Entity:GetRight( ) * 50 ) )
				
				self.InFlight = false
				
				if ( self.FireTrail ) then self.FireTrail:Remove( ) end
				
				self.Entity:SetLocalVelocity( Vector( 0, 0, 0 ) )
				
				self.Pilot = nil
				self.Entity:SetNWInt( 0, 0 )
				
				self.Accel = 0
				
			else
			
				self.Pilot:SetPos( self.Entity:GetPos( ) )
			
			end
			
			self.Entity:NextThink( CurTime( ) )
		
		else
		
			self.Sound:Stop( )
			self.Entity:NextThink( CurTime( ) + 1 )
		
		end
	
	end
	
	function ENT:Use( Player, Caller )
	
		self.Entity:SetModel( "models/jumper.mdl" )
		if ( not self.InFlight ) then
		self.Entity:SetModel( "models/jumper.mdl" )
		
			self.Sound:Play( )
			
			local PhysObj = self.Entity:GetPhysicsObject( )
				PhysObj:Wake( )
				PhysObj:EnableMotion( true )
				
			self.InFlight = true
			self.Pilot = Player
			
			Player:SetAngles( self.Entity:GetForward( ):Angle( ) )
			Player:Spectate( OBS_MODE_CHASE )
			Player:SpectateEntity( self.Entity )
			Player:DrawViewModel( false )
			Player:DrawWorldModel( false )
			Player:StripWeapons( )
			
			self.FireTrail = ents.Create( "env_fire_trail" )
				if ( not self.FireTrail ) then return end
				self.FireTrail:SetKeyValue( "spawnrate", "3" )
				self.FireTrail:SetKeyValue( "firesprite", "" )
				self.FireTrail:SetPos( self.Entity:GetPos() - ( self.Entity:GetForward( ) * 50 ) )
				self.FireTrail:SetParent( self.Entity )
				self.FireTrail:Spawn( )
				self.FireTrail:Activate( )
				
			self.Entity:NextThink( CurTime( ) + 1 )
			
			self.Entity:SetNWInt( 0, self.Pilot:EntIndex( ) )
		
		end
	
	end
	
	function ENT:PhysicsSimulate( PhysObj, DeltaTime )
	
		if ( self.InFlight ) then
		
			local PositiveAccel = math.max( self.Accel, self.Accel * -1 )
		
			if ( self.Pilot:KeyDown( IN_ATTACK ) ) then
				
				if ( self.Accel < 0 ) then self.Accel = self.Accel + 30 else self.Accel = self.Accel + 10 end
				self.Accel = math.Clamp( self.Accel, -500, 2000 )
				
			elseif ( self.Pilot:KeyDown( IN_ATTACK2 ) ) then
			
				if ( self.Accel > 0 ) then self.Accel = self.Accel - 30 else self.Accel = self.Accel - 10 end
				self.Accel = math.Clamp( self.Accel, -500, 2000 )
				
			elseif ( self.Pilot:KeyDown( IN_RELOAD ) ) then
			
				if ( self.Accel > 0 ) then
				
					self.Accel = self.Accel  - 20
					self.Accel = math.max( self.Accel, 0 )
					
				else
				
					self.Accel = self.Accel + 20
					self.Accel = math.min( self.Accel, 0 )
					
				end
				
			elseif ( self.Accel < 0 ) then
			
				self.Accel = self.Accel + 5
				self.Accel = math.Clamp( self.Accel, -500, 0 )
			
			end
			
			PhysObj:Wake( )
			
			local pr = { }
				pr.secondstoarrive	= 1
				pr.pos				= self.Entity:GetPos( ) + self.Entity:GetForward( ) * self.Accel
					if ( self.Pilot:KeyDown( IN_DUCK ) ) then pr.pos = pr.pos + self.Entity:GetUp( ) * -30
					elseif ( self.Pilot:KeyDown( IN_JUMP ) ) then pr.pos = pr.pos + self.Entity:GetUp( ) * 40 end
				pr.maxangular		= 5000
				pr.maxangulardamp	= 10000
				pr.maxspeed			= 1000000
				pr.maxspeeddamp		= 10000
				pr.dampfactor		= 0.8
				pr.teleportdistance	= 5000
					if ( self.Pilot:KeyDown( IN_SPEED ) ) then pr.angle = self.Entity:GetAngles( )
					else pr.angle = self.Pilot:GetAimVector( ):Angle( ) end
				pr.deltatime		= DeltaTime
				
			PhysObj:ComputeShadowControl( pr )
		
		end
		
	end

end
